<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Halyk Petroleum - app-wide helper functions.
 */

if (!function_exists('vp_setting')) {
    /**
     * Get a setting by key with optional default.
     * Returns the value, or $default if not set.
     */
    function vp_setting($key, $default = null)
    {
        $CI =& get_instance();
        if (!isset($CI->settings)) return $default;
        return $CI->settings->get($key, $default);
    }
}

if (!function_exists('jet_settings_group')) {
    /**
     * Get all settings in a group.
     */
    function jet_settings_group($group)
    {
        $CI =& get_instance();
        if (!isset($CI->settings)) return [];
        return $CI->settings->by_group($group);
    }
}

if (!function_exists('vp_money')) {
    /**
     * Format a money amount.
     */
    function vp_money($amount, $currency = 'USD')
    {
        if ($amount === null || $amount === '') return '—';
        $sym = ['USD' => '$', 'EUR' => '€', 'GBP' => '£', 'INR' => '₹'][$currency] ?? '$';
        return $sym . number_format((float) $amount, 2);
    }
}

if (!function_exists('vp_condition_badge')) {
    /**
     * Return [label, css_classes] for a part condition (NEW/OHC/USED/…).
     * Used by part cards and the part detail page.
     */
    function vp_condition_badge($condition)
    {
        $c = strtoupper((string) ($condition ?: 'NEW'));
        $map = [
            'NEW'         => ['NEW', 'bg-emerald-100 text-emerald-800'],
            'OHC'         => ['OHC', 'bg-amber-100 text-amber-800'],
            'OVERHAULED'  => ['OHC', 'bg-amber-100 text-amber-800'],
            'USED'        => ['USED', 'bg-sky-100 text-sky-800'],
            'SERVICEABLE' => ['SVCE', 'bg-violet-100 text-violet-800'],
        ];
        return $map[$c] ?? [$c, 'bg-gray-100 text-gray-700'];
    }
}

if (!function_exists('vp_part_price')) {
    /**
     * Render a part price with an "RFQ" fallback when the price is empty
     * (common for engines and high-value rotables).
     */
    function vp_part_price($price)
    {
        if ($price === null || $price === '') return '<span class="text-ink-800 font-semibold text-sm">Price on request</span>';
        return '<span class="font-bold text-lg text-ink-900">' . vp_money($price) . '</span>';
    }
}

if (!function_exists('vp_slugify')) {
    /**
     * Make a URL slug from a string.
     */
    function vp_slugify($text)
    {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        $text = strtolower($text);
        if (empty($text)) return 'n-a';
        return $text;
    }
}

if (!function_exists('vp_truncate')) {
    /**
     * Truncate a string to $limit chars at word boundary.
     */
    function vp_truncate($text, $limit = 200, $suffix = '…')
    {
        $text = strip_tags((string) $text);
        if (mb_strlen($text) <= $limit) return $text;
        $cut = mb_substr($text, 0, $limit);
        $space = mb_strrpos($cut, ' ');
        if ($space !== false) $cut = mb_substr($cut, 0, $space);
        return $cut . $suffix;
    }
}

if (!function_exists('vp_human_date')) {
    /**
     * Format a datetime for display.
     */
    function vp_human_date($dt, $format = 'M j, Y')
    {
        if (!$dt) return '';
        if (is_string($dt)) $dt = strtotime($dt);
        return date($format, $dt);
    }
}

if (!function_exists('vp_time_ago')) {
    /**
     * Returns "3 hours ago" style string.
     */
    function vp_time_ago($dt)
    {
        if (!$dt) return '';
        if (is_string($dt)) $dt = strtotime($dt);
        $diff = time() - $dt;
        if ($diff < 60)        return $diff . 's ago';
        if ($diff < 3600)      return floor($diff / 60) . 'm ago';
        if ($diff < 86400)     return floor($diff / 3600) . 'h ago';
        if ($diff < 2592000)   return floor($diff / 86400) . 'd ago';
        if ($diff < 31536000)  return floor($diff / 2592000) . 'mo ago';
        return floor($diff / 31536000) . 'y ago';
    }
}

if (!function_exists('vp_quote_status_label')) {
    /**
     * Display label + Bootstrap class for a quote status.
     */
    function vp_quote_status_label($status)
    {
        $map = [
            QUOTE_NEW       => ['label' => 'New',       'class' => 'bg-blue-100 text-blue-800'],
            QUOTE_REVIEWING => ['label' => 'Reviewing', 'class' => 'bg-yellow-100 text-yellow-800'],
            QUOTE_QUOTED    => ['label' => 'Quoted',    'class' => 'bg-indigo-100 text-indigo-800'],
            QUOTE_APPROVED  => ['label' => 'Approved',  'class' => 'bg-green-100 text-green-800'],
            QUOTE_REJECTED  => ['label' => 'Rejected',  'class' => 'bg-red-100 text-red-800'],
            QUOTE_COMPLETED => ['label' => 'Completed', 'class' => 'bg-gray-200 text-gray-800'],
        ];
        return $map[$status] ?? ['label' => $status, 'class' => 'bg-gray-100 text-gray-800'];
    }
}

if (!function_exists('vp_role_label')) {
    function vp_role_label($role)
    {
        $map = [
            ROLE_SUPER_ADMIN => 'Super Admin',
            ROLE_ADMIN       => 'Admin',
            ROLE_SALES       => 'Sales',
            ROLE_ENGINEER    => 'Engineer',
            ROLE_EDITOR      => 'Editor',
            ROLE_CUSTOMER    => 'Customer',
        ];
        return $map[$role] ?? $role;
    }
}

if (!function_exists('vp_avatar_url')) {
    /**
     * Return a saved profile avatar when available, otherwise fall back to
     * Gravatar. Accepts either a user row array or an email string.
     */
    function vp_avatar_url($user_or_email, $size = 80, $avatar = null)
    {
        if (is_array($user_or_email)) {
            $avatar = $user_or_email['avatar'] ?? $avatar;
            $email = $user_or_email['email'] ?? '';
        } else {
            $email = $user_or_email;
        }

        $avatar = trim((string) $avatar);
        if ($avatar !== '') {
            if (function_exists('vp_asset_url')) return vp_asset_url($avatar);
            if (preg_match('~^(https?:)?//~i', $avatar) || strpos($avatar, 'data:') === 0 || $avatar[0] === '/') return $avatar;
            return '/' . ltrim($avatar, '/');
        }

        $hash = md5(strtolower(trim((string) $email)));
        return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . (int) $size . '&d=mp';
    }
}

if (!function_exists('vp_safe_html')) {
    /**
     * Output a string with HTML escaping.
     */
    function vp_safe_html($s)
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('vp_excerpt_from_html')) {
    /**
     * Strip tags and truncate.
     */
    function vp_excerpt_from_html($html, $limit = 200)
    {
        return vp_truncate($html, $limit);
    }
}

if (!function_exists('vp_pagination_links')) {
    /**
     * Build a simple Bootstrap-style pagination block.
     *
     * @param string $base  Base URL with {page} placeholder, e.g. '/products?page={page}'
     */
    function vp_pagination_links($total_pages, $page, $base)
    {
        if ($total_pages <= 1) return '';
        $page = max(1, (int) $page);
        $html = '<nav class="vp-pagination" aria-label="Pagination"><ul class="inline-flex -space-x-px">';
        $prev = max(1, $page - 1);
        $next = min($total_pages, $page + 1);
        $url_for = function ($p) use ($base) { return str_replace('{page}', (string) $p, $base); };

        $html .= '<li><a class="px-3 py-2 border rounded-l-lg ' . ($page <= 1 ? 'text-ink-800 pointer-events-none' : 'hover:bg-gray-100') . '" href="' . $url_for($prev) . '">Prev</a></li>';
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i === 1 || $i === $total_pages || abs($i - $page) <= 2) {
                $cls = ($i === $page) ? 'bg-blue-600 text-white' : 'hover:bg-gray-100';
                $html .= '<li><a class="px-3 py-2 border ' . $cls . '" href="' . $url_for($i) . '">' . $i . '</a></li>';
            } elseif (abs($i - $page) === 3) {
                $html .= '<li><span class="px-3 py-2 border">…</span></li>';
            }
        }
        $html .= '<li><a class="px-3 py-2 border rounded-r-lg ' . ($page >= $total_pages ? 'text-ink-800 pointer-events-none' : 'hover:bg-gray-100') . '" href="' . $url_for($next) . '">Next</a></li>';
        $html .= '</ul></nav>';
        return $html;
    }
}

if (!function_exists('vp_product_image')) {
    /**
     * Resolve the best available image URL for a product row.
     *
     * Resolution order:
     *   1. `imageUrl`  - uploaded primary image (Product_model::attach_images)
     *   2. `image`     - a legacy single-image column, if present
     *   3. dedicated artwork for each seeded catalog product
     *   4. category artwork  /assets/img/products/<category-slug>.jpg
     *      (wheels-brakes, landing-gear, avionics, engines-apus,
     *       flight-controls, hydraulics, pneumatics, electrical-lighting,
     *       interior-cabin, actuators-valves, fuel-systems, airframe - the
     *       files shipped in app/assets/img/products/)
     *   5. a keyword guess from the product name, so a product with no
     *      category still gets a relevant photo instead of the placeholder
     *   6. /assets/img/products/default.jpg
     *
     * @param  array|null  $product   Product row
     * @param  string|null $categorySlug Optional explicit category slug
     * @return string      Absolute-from-root image URL
     */
    function vp_product_image($product, $categorySlug = null)
    {
        $product = (array) $product;
        $default = IMG_URL . 'products/default.jpg';

        // 1 + 2: a real uploaded image always wins.
        foreach (['imageUrl', 'image'] as $k) {
            if (!empty($product[$k])) return $product[$k];
        }

        // 2b: a dedicated per-product image /assets/img/products/<slug>.jpg.
        // Each seeded part has its own illustration so catalog cards do not
        // all share the one category image. Fall back silently when missing.
        foreach (['slug', 'id'] as $key) {
            if (!empty($product[$key]) && strpos((string) $product[$key], '/') === false) {
                $candidate = FCPATH . ltrim(IMG_URL, '/') . 'products/' . rawurlencode((string) $product[$key]) . '.jpg';
                if (is_file($candidate)) {
                    return IMG_URL . 'products/' . $product[$key] . '.jpg';
                }
            }
        }

        // Seeded catalog products map to curated artwork when a per-product
        // file is not present. Uploaded images above still take precedence.
        $productArtwork = [
            'main-landing-gear-wheel-2612201-2'   => 'wheels-brakes.jpg',
            'main-wheel-brake-2-1553-5'           => 'wheels-brakes.jpg',
            'carbon-brake-2612401-1'              => 'wheels-brakes.jpg',
            'nose-wheel-208-150-0'                => 'wheels-brakes.jpg',
            'main-gear-tire-132-101-0'            => 'wheels-brakes.jpg',
            'anti-skid-control-20-57-03'          => 'wheels-brakes.jpg',
            'nose-landing-gear-9001252-3'         => 'landing-gear.jpg',
            'main-landing-gear-actuator-9001340-5'=> 'landing-gear.jpg',
            'nose-wheel-steering-46-162-01'       => 'landing-gear.jpg',
            'landing-gear-control-82-345-2'       => 'landing-gear.jpg',
            'vhf-4000-comm-radio'                 => 'avionics.jpg',
            'primus-660-weather-radar'            => 'avionics.jpg',
            'laseref-iv-inertial-reference'       => 'avionics.jpg',
            'kmd-850-multifunction-display'       => 'avionics.jpg',
            'flight-data-recorder-980-4700-043'   => 'avionics.jpg',
            'gtcp36-150-apu'                      => 'engines-apus.jpg',
            'cfe738-1-1b-turbofan'                => 'engines-apus.jpg',
            'tfe731-5br-1c-engine'                => 'engines-apus.jpg',
            'edp-hydraulic-pump'                  => 'hydraulics.jpg',
            'hydraulic-system-valve-25d-660'      => 'hydraulics.jpg',
            'rudder-servo-523-0771-517'           => 'flight-controls.jpg',
            'elevator-trim-actuator'              => 'flight-controls.jpg',
            'rudder-pcu-692-0241-001'             => 'flight-controls.jpg',
            'bleed-air-regulating-valve'          => 'pneumatics.jpg',
            'cabin-pressure-controller'           => 'pneumatics.jpg',
            'fuel-boost-pump'                     => 'fuel-systems.jpg',
            'fuel-quantity-indicator'             => 'fuel-systems.jpg',
            'starter-generator'                   => 'electrical-lighting.jpg',
            'nicd-main-battery'                   => 'electrical-lighting.jpg',
            'landing-light-assembly'              => 'electrical-lighting.jpg',
            'emergency-oxygen-system'             => 'interior-cabin.jpg',
            'emergency-escape-slide'              => 'interior-cabin.jpg',
            'cabin-window-assembly'               => 'interior-cabin.jpg',
            'flap-actuator'                       => 'actuators-valves.jpg',
            'solenoid-shutoff-valve'              => 'actuators-valves.jpg',
            'engine-cowling-rh'                   => 'airframe.jpg',
            'apu-fire-extinguisher'               => 'airframe.jpg',
        ];
        $productSlug = $product['slug'] ?? '';
        if (isset($productArtwork[$productSlug])) {
            return IMG_URL . 'products/' . $productArtwork[$productSlug];
        }

        // Category artwork shipped with the theme.
        $known = [
            'wheels-brakes', 'landing-gear', 'avionics', 'engines-apus',
            'flight-controls', 'hydraulics', 'pneumatics', 'electrical-lighting',
            'interior-cabin', 'actuators-valves', 'fuel-systems', 'airframe',
        ];

        $slug = $categorySlug ?: ($product['categorySlug'] ?? null);
        if ($slug && in_array($slug, $known, true)) {
            return IMG_URL . 'products/' . $slug . '.jpg';
        }

        // 4: keyword guess from the product name / sku / description.
        $hay = strtolower(trim(($product['name'] ?? '') . ' ' . ($product['shortDescription'] ?? '')));
        if ($hay !== '') {
            $map = [
                'wheels-brakes'      => ['wheel', 'brake', 'tire', 'tyre', 'anti-skid', 'antiskid', 'axle', 'hub'],
                'fuel-systems'       => ['fuel pump', 'fuel quantity', 'fuel system', 'fuel valve', 'boost pump', 'fuel cell', 'fuel indicator'],
                'hydraulics'         => ['hydraulic pump', 'hydraulic valve', 'hydraulic system', 'edp', 'reservoir', 'accumulator', 'hydraulic motor'],
                'flight-controls'    => ['servo', 'rudder', 'elevator', 'aileron', 'spoiler', 'trim', 'pcu', 'power control', 'flap', 'yaw damper'],
                'landing-gear'       => ['landing gear', 'nose gear', 'main gear', 'strut', 'oleo', 'steering actuator', 'gear assembly', 'gear control'],
                'pneumatics'         => ['bleed air', 'pneumatic', 'pressure controller', 'outflow valve', 'air cycle', 'precooler', 'duct'],
                'electrical-lighting'=> ['generator', 'starter', 'battery', 'light', 'lamp', 'relay', 'contactor', 'inverter', 'transformer', 'electrical'],
                'interior-cabin'     => ['oxygen', 'escape slide', 'cabin window', 'seat', 'galley', 'lavatory', 'interior', 'cabin'],
                'avionics'           => ['radio', 'radar', 'display', 'mfd', 'transponder', 'gps', 'nav', 'gyro', 'attitude', 'indicator', 'recorder', 'instrument', 'avionics', 'efis', 'inertial', 'comm'],
                'actuators-valves'   => ['actuator', 'valve', 'solenoid', 'shutoff'],
                'airframe'           => ['cowling', 'fairing', 'airframe', 'structure', 'skin', 'wing tip', 'fire extinguisher', 'fire bottle'],
                'engines-apus'       => ['turbofan', 'engine', 'apu', 'auxiliary power', 'core', 'combustor', 'turbine'],
            ];
            foreach ($map as $folderSlug => $needles) {
                foreach ($needles as $n) {
                    if (strpos($hay, $n) !== false) {
                        return IMG_URL . 'products/' . $folderSlug . '.jpg';
                    }
                }
            }
        }

        return $default;
    }
}

if (!function_exists('vp_category_image')) {
    /**
     * Resolve the best available image URL for a category row.
     *
     * Resolution order:
     *   1. `image`       - a stored category image, used only while the file
     *                      (or external URL) is actually loadable; a stale or
     *                      deleted path silently falls through
     *   2. dedicated artwork /assets/img/products/<category-slug>.jpg
     *                      (the files shipped with the theme: wheels-brakes,
     *                      landing-gear, avionics, engines-apus,
     *                      flight-controls, hydraulics, pneumatics,
     *                      electrical-lighting, interior-cabin,
     *                      actuators-valves, fuel-systems, airframe)
     *   3. a keyword guess from the category name, so admin-created
     *      categories still get a relevant photo
     *   4. /assets/img/products/default.jpg
     *
     * @param  array|null $category  Category row
     * @return string     Absolute-from-root image URL
     */
    function vp_category_image($category)
    {
        $category = (array) $category;
        $default  = IMG_URL . 'products/default.jpg';
        $slug     = trim((string) ($category['slug'] ?? ''));

        // 1: a stored image wins, but only while the file really exists.
        $stored = trim((string) ($category['image'] ?? ''));
        if ($stored !== '') {
            $resolved = function_exists('vp_existing_asset_url')
                ? vp_existing_asset_url($stored, '')
                : vp_asset_url($stored);
            if ($resolved !== '') return $resolved;
        }

        // 2: canonical per-category artwork shipped with the theme.
        if ($slug !== '' && strpos($slug, '/') === false && strpos($slug, '..') === false) {
            $rel = ltrim(IMG_URL, '/') . 'products/' . rawurlencode($slug) . '.jpg';
            if (is_file(FCPATH . $rel)) {
                return IMG_URL . 'products/' . $slug . '.jpg';
            }
        }

        // 3: keyword guess from the category name.
        $hay = strtolower(trim((string) ($category['name'] ?? '')));
        if ($hay !== '') {
            $map = [
                'wheels-brakes'       => ['wheel', 'brake', 'tire', 'tyre', 'anti-skid', 'antiskid', 'axle', 'hub'],
                'landing-gear'        => ['landing gear', 'nose gear', 'main gear', 'gear assembly', 'strut', 'oleo', 'steering'],
                'avionics'            => ['avionic', 'radio', 'radar', 'display', 'mfd', 'transponder', 'gps', 'nav', 'gyro', 'attitude', 'indicator', 'recorder', 'instrument', 'efis', 'inertial', 'comm'],
                'engines-apus'        => ['engine', 'apu', 'turbofan', 'turbine', 'power plant', 'powerplant', 'auxiliary power', 'core', 'combustor'],
                'flight-controls'     => ['flight control', 'servo', 'rudder', 'elevator', 'aileron', 'spoiler', 'trim', 'pcu', 'power control', 'flap', 'control surface'],
                'hydraulics'          => ['hydraulic', 'reservoir', 'accumulator'],
                'pneumatics'          => ['pneumatic', 'bleed air', 'pressure controller', 'outflow valve', 'air cycle', 'precooler', 'duct'],
                'electrical-lighting' => ['electrical', 'lighting', 'generator', 'starter', 'battery', 'lamp', 'relay', 'contactor', 'inverter', 'transformer', 'power distribution'],
                'interior-cabin'      => ['interior', 'cabin', 'oxygen', 'escape slide', 'seat', 'galley', 'lavatory', 'window'],
                'actuators-valves'    => ['actuator', 'valve', 'solenoid', 'shutoff'],
                'fuel-systems'        => ['fuel', 'boost pump', 'quantity', 'tank'],
                'airframe'            => ['airframe', 'structure', 'cowling', 'fairing', 'skin', 'fuselage', 'wing'],
            ];
            foreach ($map as $folderSlug => $needles) {
                foreach ($needles as $n) {
                    if (strpos($hay, $n) !== false) {
                        return IMG_URL . 'products/' . $folderSlug . '.jpg';
                    }
                }
            }
        }

        return $default;
    }
}

if (!function_exists('vp_product_image_tag')) {
    /**
     * Render a complete <img> for a product card, with an onerror fallback so
     * a deleted upload can never leave a broken-image icon on the page.
     *
     * @param array|null $product
     * @param string     $class  CSS classes for the <img>
     * @param string|null $categorySlug
     * @param string     $loading 'lazy' (default) or 'eager'
     */
    function vp_product_image_tag($product, $class = 'w-full h-full object-cover', $categorySlug = null, $loading = 'lazy')
    {
        $product = (array) $product;
        $src = vp_product_image($product, $categorySlug);
        $alt = $product['imageAlt'] ?? ($product['name'] ?? 'Product');
        $fallback = IMG_URL . 'products/default.jpg';
        return '<img src="' . vp_safe_html($src) . '"'
            . ' alt="' . vp_safe_html($alt) . '"'
            . ' loading="' . vp_safe_html($loading) . '" decoding="async"'
            . ' class="' . vp_safe_html($class) . '"'
            . ' onerror="this.onerror=null;this.src=\'' . $fallback . '\'">';
    }
}

if (!function_exists('vp_industry_image')) {
    /**
     * Resolve industry / aircraft-platform artwork.
     *
     * Resolution order:
     *   1. The row's own `image` column (admin upload) when it points at a file
     *      that actually exists on disk.
     *   2. `/assets/img/industries/<slug>.jpg` whenever that artwork ships with
     *      the theme. This is what gives every aircraft platform page its own
     *      banner — Gulfstream, Dassault Falcon, Hawker, Pilatus, Airbus,
     *      Embraer, Boeing, Learjet, Challenger and Cessna Citation each have
     *      dedicated artwork in that folder.
     *   3. `/assets/img/industries/default.jpg` for anything unknown, so a
     *      missing file can never leave a card or hero empty.
     *
     * The previous implementation whitelisted only the served-market slugs and
     * sent every aircraft platform to `default.jpg`, so all ten platform pages
     * (and the /industries grid) rendered the same generic photo. Resolving
     * against the filesystem instead of a hard-coded list also means a newly
     * added platform only needs its own artwork dropped into the folder.
     *
     * @param array|object $industry Industry row (needs `slug` or `name`)
     * @return string Absolute URL/path to the artwork
     */
    function vp_industry_image($industry)
    {
        $industry = (array) $industry;
        $dir = FCPATH . 'assets/img/industries/';

        // 1. Admin-stored image, but only when the file is really there. A stale
        //    path (deleted upload, renamed slug) falls through to the theme art.
        $stored = trim((string) ($industry['image'] ?? ''));
        if ($stored !== '') {
            if (strpos($stored, 'http://') === 0 || strpos($stored, 'https://') === 0) {
                return $stored;
            }
            $rel = ltrim(str_replace('\\', '/', $stored), '/');
            if (is_file(FCPATH . $rel)) {
                return $stored;
            }
            // Uploads outside assets/img/industries/ are trusted as-is: they may
            // live on a volume we cannot stat, and only the theme folder has a
            // guaranteed fallback below.
            if (strpos($rel, 'assets/img/industries/') !== 0) {
                return $stored;
            }
        }

        // 2. Per-slug theme artwork.
        $slug = vp_slugify($industry['slug'] ?? $industry['name'] ?? 'default');
        if ($slug !== '' && is_file($dir . $slug . '.jpg')) {
            return IMG_URL . 'industries/' . $slug . '.jpg';
        }

        // 3. Generic parts/warehouse fallback.
        return IMG_URL . 'industries/default.jpg';
    }
}

if (!function_exists('vp_blog_image')) {
    /** Resolve editorial artwork. Uploaded artwork wins over curated local fallbacks. */
    function vp_blog_image($post)
    {
        $post = (array) $post;

        // An uploaded featured image wins — but only when its file is really
        // there. A stale upload path used to render a broken image on the
        // article page and in the blog grid; now it falls through to the
        // curated artwork below.
        $uploaded = trim((string) ($post['featuredImage'] ?? ''));
        if ($uploaded !== '' && function_exists('vp_existing_asset_url')) {
            $resolved = vp_existing_asset_url($uploaded);
            if ($resolved !== '') return $resolved;
        } elseif ($uploaded !== '') {
            return $uploaded;
        }

        // Curated editorial artwork, verified the same way.
        $slug = $post['slug'] ?? '';
        if (strpos($slug, 'new-vs-ohc') !== false || strpos($slug, 'new-ohc') !== false || strpos($slug, 'condition') !== false) {
            return vp_existing_asset_url(IMG_URL . 'products/wheels-brakes.jpg', IMG_URL . 'blog/asme-pressure-vessel.jpg');
        }
        if (strpos($slug, '8130') !== false || strpos($slug, 'certificate') !== false || strpos($slug, 'easa') !== false) {
            return vp_existing_asset_url(IMG_URL . 'products/avionics.jpg', IMG_URL . 'blog/asme-pressure-vessel.jpg');
        }
        return vp_existing_asset_url(IMG_URL . 'blog/asme-pressure-vessel.jpg', IMG_URL . 'hero-jet.jpg');
    }
}

if (!function_exists('vp_testimonial_image')) {
    /**
     * Resolve a customer-review portrait. Uploaded avatar wins; otherwise
     * fall back to the curated headshots shipped with the theme.
     */
    function vp_testimonial_image($testimonial)
    {
        $t = (array) $testimonial;
        if (!empty($t['avatar'])) {
            $avatar = (string) $t['avatar'];
            $local = (preg_match('~^https?://~i', $avatar)) ? null : (FCPATH . ltrim($avatar, '/'));
            if (preg_match('~^https?://~i', $avatar) || is_file($local)) {
                return $avatar;
            }
            // Fall through: the referenced avatar file does not exist yet —
            // use a curated headshot instead of showing a broken image.
        }

        $slug = vp_slugify($t['name'] ?? '');
        $map = [
            'mark-hendricks'   => 'reviews/mark-hendricks.jpg',
            'sofia-marchetti'  => 'reviews/sofia-marchetti.jpg',
            'david-okafor'     => 'reviews/david-okafor.jpg',
            'elena-kovac'      => 'reviews/elena-kovac.jpg',
            'mark-henderson'   => 'reviews/mark-henderson.jpg',
            'linda-park'       => 'reviews/linda-park.jpg',
            'akhil-raman'      => 'reviews/akhil-raman.jpg',
            'jonas-weber'      => 'reviews/jonas-weber.jpg',
        ];
        if (isset($map[$slug]) && is_file(FCPATH . 'assets/img/' . $map[$slug])) {
            return IMG_URL . $map[$slug];
        }
        return IMG_URL . 'reviews/mark-henderson.jpg';
    }
}

if (!function_exists('vp_news_image')) {
    /** Resolve news artwork from the CMS or the subject of a seeded story. */
    function vp_news_image($story)
    {
        $story = (array) $story;
        if (!empty($story['image'])) return $story['image'];
        $slug = $story['slug'] ?? '';
        if (strpos($slug, 'aog') !== false) return IMG_URL . 'news/aog-dispatch.jpg';
        if (strpos($slug, 'inventory') !== false || strpos($slug, 'parts') !== false) return IMG_URL . 'hero-hangar.jpg';
        if (strpos($slug, 'as9120') !== false || strpos($slug, 'quality') !== false) return IMG_URL . 'about-hangar.jpg';
        return IMG_URL . 'news/default.jpg';
    }
}

if (!function_exists('vp_format_bytes')) {
    function vp_format_bytes($bytes, $precision = 1)
    {
        $units = ['B','KB','MB','GB','TB'];
        $bytes = max($bytes, 0);
        $pow = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}

if (!function_exists('vp_quote_number')) {
    /**
     * Generate a human-friendly quote/RFQ number, e.g. HP-2026-000123.
     * HP = Halyk Petroleum. Legacy VP- numbers are renumbered by migration 009.
     */
    function vp_quote_number()
    {
        static $seq = null;
        $year = date('Y');
        $CI =& get_instance();
        if ($seq === null) {
            // Count this year's quotes under either prefix so numbering never
            // collides with legacy rows.
            $CI->db->select('COUNT(*) AS c');
            $CI->db->from('quotes');
            $CI->db->group_start();
            $CI->db->like('quoteNumber', 'HP-' . $year, 'after');
            $CI->db->or_like('quoteNumber', 'VP-' . $year, 'after');
            $CI->db->group_end();
            $row = $CI->db->get()->row_array();
            $seq = (int) ($row['c'] ?? 0);
        }
        $seq++;
        return 'HP-' . $year . '-' . str_pad((string) $seq, 6, '0', STR_PAD_LEFT);
    }
}

/* --------------------------------------------------------------------- */
/* SEO                                                                   */
/* --------------------------------------------------------------------- */

if (!function_exists('vp_seo_config')) {
    /**
     * Merge the SEO settings (settings table, group "SEO") with safe defaults.
     * Every key has a fallback so the site renders correct SEO even before
     * the admin has configured anything.
     */
    function vp_seo_config()
    {
        $CI   =& get_instance();
        // Dashboard-managed identity wins over the config defaults.
        $site    = $CI->settings->get('site_name') ?: ($CI->config->item('site_name') ?: 'Halyk Petroleum');
        $tagline = $CI->settings->get('site_description')
                    ?: ($CI->settings->get('site_tagline') ?: ($CI->config->item('site_tagline') ?: 'Aircraft Parts & Components Supply'));

        // Fall back to $default when the stored value is missing OR empty,
        // so clearing a field in admin restores the sensible default.
        $val = function ($key, $default = '') use ($CI) {
            $v = $CI->settings->get($key);
            if ($v === null || $v === '') return $default;
            return $v;
        };
        $bool = function ($key, $default = true) use ($CI) {
            $v = $CI->settings->get($key);
            if ($v === null || $v === '') return $default;
            if (is_bool($v)) return $v;
            return $v === '1' || $v === 'true' || $v === 'on';
        };

        return [
            'title_suffix'        => (string) $val('seo_title_suffix', ' | ' . $site),
            'default_title'       => (string) $val('seo_default_title', $site),
            'default_description' => (string) $val('seo_default_description', $tagline),
            'keywords'            => (string) $val('seo_keywords', ''),
            'robots'              => (string) $val('seo_robots', 'index, follow'),
            'og_image'            => (string) $val('seo_og_image', IMG_URL . 'hero-jet.jpg'),
            'canonical_domain'    => rtrim((string) $val('seo_canonical_domain', ''), '/'),
            'twitter_site'        => (string) $val('seo_twitter_site', ''),
            'facebook_app_id'     => (string) $val('seo_facebook_app_id', ''),
            'google_verification' => (string) $val('seo_google_verification', ''),
            'bing_verification'   => (string) $val('seo_bing_verification', ''),
            'google_analytics'   => (string) $val('seo_google_analytics', ''),
            'enable_jsonld'       => $bool('seo_enable_jsonld', true),
            'schema_type'         => (string) $val('seo_schema_type', 'Organization'),
            'schema_name'         => (string) $val('seo_schema_name', $site),
            'schema_logo'         => (string) $val('seo_schema_logo', function_exists('vp_logo_url') ? vp_logo_url('light') : IMG_URL . 'logo-header.png'),
            'schema_json'         => trim((string) $val('seo_schema_json', '')),
        ];
    }
}

if (!function_exists('vp_seo_canonical_url')) {
    /**
     * Build the canonical URL for the current request.
     * Uses the configured canonical domain when set, otherwise the base URL.
     * Query strings are dropped (canonical points at the canonical resource).
     */
    function vp_seo_canonical_url($url = null)
    {
        $CI  =& get_instance();
        $seo = vp_seo_config();
        $url = $url ?: current_url();

        $path = parse_url($url, PHP_URL_PATH) ?: '/';
        if (!empty($seo['canonical_domain'])) {
            return $seo['canonical_domain'] . $path;
        }
        $base = rtrim($CI->config->item('base_url'), '/');
        return $base . $path;
    }
}

if (!function_exists('vp_seo_jsonld')) {
    /**
     * Build the JSON-LD structured data block (Organization by default, or a
     * fully custom document when seo_schema_json is configured).
     */
    function vp_seo_jsonld($nonce = '')
    {
        $seo = vp_seo_config();
        if (!$seo['enable_jsonld']) return '';

        $url = vp_seo_canonical_url();

        if ($seo['schema_json'] !== '') {
            $json = $seo['schema_json'];
            if (json_decode($json) === null) return ''; // refuse to emit invalid JSON
        } else {
            $schema = [
                '@context' => 'https://schema.org',
                '@type'    => $seo['schema_type'],
                'name'     => $seo['schema_name'],
                'url'      => $url,
            ];
            if (strtolower($seo['schema_type']) === 'organization') {
                $schema['logo'] = $seo['schema_logo'];
                $CI =& get_instance();
                $contact = [
                    '@type'       => 'ContactPoint',
                    'contactType' => 'sales',
                    'telephone'   => $CI->config->item('phone') ?: '',
                    'email'       => $CI->config->item('contact_email') ?: '',
                ];
                if ($contact['telephone'] || $contact['email']) $schema['contactPoint'] = $contact;
            }
            $json = json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        $nonceAttr = $nonce !== '' ? ' nonce="' . vp_safe_html($nonce) . '"' : '';
        return '<script type="application/ld+json"' . $nonceAttr . '>' . $json . '</script>';
    }
}

if (!function_exists('vp_seo_head')) {
    /**
     * Render the full <head> SEO block: title, description, keywords, robots,
     * canonical, Open Graph, Twitter Card, site verification and JSON-LD.
     *
     * @param string $page_title       Page-specific title (no site suffix)
     * @param string $page_description Page-specific meta description
     * @param string $url              Canonical URL (defaults to current URL)
     * @param string $nonce            CSP nonce for the JSON-LD script tag
     */
    function vp_seo_head($page_title, $page_description, $url = null, $nonce = '')
    {
        $CI   =& get_instance();
        $seo  = vp_seo_config();
        $site = function_exists('vp_site') ? vp_site('name') : ($CI->config->item('site_name') ?: 'Halyk Petroleum');

        $title = trim((string) $page_title) !== '' ? $page_title : $seo['default_title'];
        // Do not repeat the site name when the page title already carries it.
        if (stripos($title, trim((string) $site)) === false) {
            $title .= $seo['title_suffix'];
        }
        $desc  = trim((string) $page_description) !== '' ? $page_description : $seo['default_description'];
        $canonical = vp_seo_canonical_url($url);

        $out  = '<title>' . vp_safe_html($title) . '</title>' . "\n";
        $out .= '<meta name="description" content="' . vp_safe_html($desc) . '">' . "\n";
        if ($seo['keywords'] !== '') {
            $out .= '<meta name="keywords" content="' . vp_safe_html($seo['keywords']) . '">' . "\n";
        }
        $out .= '<meta name="robots" content="' . vp_safe_html($seo['robots']) . '">' . "\n";
        $out .= '<link rel="canonical" href="' . vp_safe_html($canonical) . '">' . "\n";

        // Open Graph
        $out .= '<meta property="og:type" content="website">' . "\n";
        $out .= '<meta property="og:site_name" content="' . vp_safe_html($site) . '">' . "\n";
        $out .= '<meta property="og:title" content="' . vp_safe_html($title) . '">' . "\n";
        $out .= '<meta property="og:description" content="' . vp_safe_html($desc) . '">' . "\n";
        $out .= '<meta property="og:url" content="' . vp_safe_html($canonical) . '">' . "\n";
        $out .= '<meta property="og:image" content="' . vp_safe_html($seo['og_image']) . '">' . "\n";
        if ($seo['facebook_app_id'] !== '') {
            $out .= '<meta property="fb:app_id" content="' . vp_safe_html($seo['facebook_app_id']) . '">' . "\n";
        }

        // Twitter Card
        $out .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
        $out .= '<meta name="twitter:title" content="' . vp_safe_html($title) . '">' . "\n";
        $out .= '<meta name="twitter:description" content="' . vp_safe_html($desc) . '">' . "\n";
        $out .= '<meta name="twitter:image" content="' . vp_safe_html($seo['og_image']) . '">' . "\n";
        if ($seo['twitter_site'] !== '') {
            $out .= '<meta name="twitter:site" content="' . vp_safe_html($seo['twitter_site']) . '">' . "\n";
        }

        // Search-engine site verification
        if ($seo['google_verification'] !== '') {
            $out .= '<meta name="google-site-verification" content="' . vp_safe_html($seo['google_verification']) . '">' . "\n";
        }
        if ($seo['bing_verification'] !== '') {
            $out .= '<meta name="msvalidate.01" content="' . vp_safe_html($seo['bing_verification']) . '">' . "\n";
        }

        // Google Analytics 4 (optional — set the GA4 Measurement ID in SEO settings)
        if ($seo['google_analytics'] !== '') {
            $ga = vp_safe_html($seo['google_analytics']);
            $out .= '<script async src="https://www.googletagmanager.com/gtag/js?id=' . $ga . '"></script>' . "\n";
            $out .= '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config","' . $ga . '");</script>' . "\n";
        }

        // Structured data
        $out .= vp_seo_jsonld($nonce);

        return $out;
    }
}

/* --------------------------------------------------------------------- */
/* AI Chat                                                               */
/* --------------------------------------------------------------------- */

if (!function_exists('vp_chat_config')) {
    /**
     * Merge the AI chat settings (settings table, group "CHAT") with defaults.
     */
    function vp_chat_config()
    {
        $CI   =& get_instance();
        $site = $CI->config->item('site_name') ?: 'Halyk Petroleum';

        $quick = vp_setting('chat_quick_replies', []);
        if (is_string($quick)) {
            $decoded = json_decode($quick, true);
            $quick = is_array($decoded) ? $decoded : [];
        }

        // Secrets / provider config can come from the settings table or the
        // environment (VP_AI_*). Env wins when both are present.
        $env = function_exists('vp_config_env') ? 'vp_config_env' : null;

        return [
            'enabled'       => (bool) vp_setting('chat_enabled', true),
            'title'         => (string) vp_setting('chat_title', $site . ' Assistant'),
            'bot_name'      => (string) vp_setting('chat_bot_name', 'Assistant'),
            'avatar'        => (string) vp_setting('chat_avatar', IMG_URL . 'chat-bot-avatar.png'),
            'welcome'       => (string) vp_setting('chat_welcome', 'Hi there! 👋 I can help you with our products, industries, pricing and quotes. What would you like to know?'),
            'provider'      => (string) vp_setting('chat_ai_provider', 'local'),
            'api_key'       => $env ? (vp_config_env('VP_AI_API_KEY') ?: (string) vp_setting('chat_ai_api_key', '')) : (string) vp_setting('chat_ai_api_key', ''),
            'api_url'       => $env ? (vp_config_env('VP_AI_API_URL') ?: (string) vp_setting('chat_ai_api_url', 'https://api.openai.com/v1/chat/completions')) : (string) vp_setting('chat_ai_api_url', 'https://api.openai.com/v1/chat/completions'),
            'model'         => $env ? (vp_config_env('VP_AI_MODEL') ?: (string) vp_setting('chat_ai_model', 'gpt-4o-mini')) : (string) vp_setting('chat_ai_model', 'gpt-4o-mini'),
            'system_prompt' => (string) vp_setting('chat_ai_system_prompt', ''),
            'quick_replies' => $quick,
        ];
    }
}

/**
 * 🚀 Marketplace roadmap — single source of truth for "Shipped / Building / Planned".
 *
 * Used by:
 *   • public /roadmap page (modules/Roadmap_page view)
 *   • admin dashboard widget
 *   • marketing footer / status block when needed
 *
 * Status values: 'shipped' | 'building' | 'planned'. Items with status 'shipped'
 * are considered complete in production. The total % shipped is computed by
 * vp_roadmap_progress().
 */
if (!function_exists('vp_roadmap_data')) {
    function vp_roadmap_data()
    {
        return [
            [
                'name' => 'Marketplace foundation',
                'items' => [
                    ['title' => 'CI3 base, no Composer required',                       'status' => 'shipped',  'detail' => 'Works on cPanel from a raw FTP upload — no terminal, SSH, Composer or Node.js needed.'],
                    ['title' => 'Environment-driven config (.env)',                     'status' => 'shipped',  'detail' => 'Database, secrets, SMTP and site identity all live in a single .env file.'],
                    ['title' => 'RBAC with per-account overrides',                      'status' => 'shipped',  'detail' => 'Role permissions + per-user allow / deny for every dashboard section.'],
                    ['title' => 'CSRF + login + global rate limiter',                    'status' => 'shipped',  'detail' => 'Hardened by default — AOG / contact / chat / RFQ have separate buckets.'],
                ],
            ],
            [
                'name' => 'Public marketplace',
                'items' => [
                    ['title' => 'Homepage CMS section builder',                        'status' => 'shipped',  'detail' => 'Hero, stats, categories, featured parts, aircraft, testimonials, partners, CTA.'],
                    ['title' => 'Aircraft platform marketplace',                       'status' => 'shipped',  'detail' => '12 aviation part categories and 10 aircraft platforms, each with a tile.'],
                    ['title' => 'Parts search strip on every page',                    'status' => 'shipped',  'detail' => 'Header search posts live to /products?q= and respects the active category.'],
                    ['title' => 'Part detail pages with condition pills + USD price',  'status' => 'shipped',  'detail' => 'FAA 8130-3 / EASA Form 1 callouts, AOG dispatch line, RT-? RFQ + \'Ask a question\'.'],
                    ['title' => 'Request a Quote (RFQ) public flow',                  'status' => 'shipped',  'detail' => 'Multi-line items, attachments, prefilled part, 24-hr + AOG routing.'],
                    ['title' => 'Ask a question deep-link from any part',             'status' => 'shipped',  'detail' => 'Card / detail / home quick-action all jump to the contact form prefilled.'],
                    ['title' => 'AOG hotline strip in footer',                        'status' => 'shipped',  'detail' => '24/7 hotline highlighted in amber on every page.'],
                ],
            ],
            [
                'name' => 'Super Admin dashboard',
                'items' => [
                    ['title' => 'Administrator & permission management',              'status' => 'shipped',  'detail' => 'Create accounts, assign roles, grant / revoke section-level permissions.'],
                    ['title' => 'Homepage section builder',                          'status' => 'shipped',  'detail' => 'Add / reorder / hide / duplicate sections from a single screen.'],
                    ['title' => 'CMS pages, navigation, branding, header & footer',    'status' => 'shipped',  'detail' => 'Everything the public site renders is editable from the dashboard.'],
                    ['title' => 'Media library with replace / delete / update',       'status' => 'shipped',  'detail' => 'Replaces /assets/img/<file>.jpg live without breaking public URLs.'],
                    ['title' => 'Settings + SEO + Audit + Notifications',            'status' => 'shipped',  'detail' => 'Sales, AOG and careers messages route to the correct staff inbox.'],
                    ['title' => 'RFQ → admin list with status + assign + note + PDF', 'status' => 'shipped',  'detail' => 'Hardened state machine, CSV export, email on every status change.'],
                ],
            ],
            [
                'name' => 'Back-office & platform',
                'items' => [
                    ['title' => 'cPanel-friendly deployment',                         'status' => 'shipped',  'detail' => 'One .zip upload, one .sql import, edit .env in File Manager.'],
                    ['title' => 'Optional SQLite dev mode',                          'status' => 'shipped',  'detail' => 'Run the entire site from a single .sqlite file when MySQL isnt available.'],
                    ['title' => 'Resend / SMTP / mail() fallback in Mailer',          'status' => 'shipped',  'detail' => 'Auto-detects which transport is configured; never silently drops email.'],
                    ['title' => 'Audit log + per-admin activity timeline',           'status' => 'shipped',  'detail' => 'Filterable by actor, resource, action, IP and date.'],
                    ['title' => 'CSRF exclusion list for the chat widget',          'status' => 'shipped',  'detail' => 'Avoids 403 when a CDN strips the rotated CSRF cookie on rapid messages.'],
                    ['title' => 'Stripe / card payments',                            'status' => 'shipped',  'detail' => 'Approved quotes can be paid through Stripe-hosted Checkout, with signed webhooks, payment ledger and automatic completion.'],
                    ['title' => 'Multi-warehouse inventory & lot tracking',         'status' => 'shipped',  'detail' => 'Warehouse-level lots, reserved stock, expiry control, AOG hubs, movement ledger and safe public stock aggregates.'],
                    ['title' => 'Customer accounts + parts-order history',           'status' => 'shipped', 'detail' => 'Signed-in customers re-order past quotes, download PDF invoices from paid card orders, and track AOG dispatches from /account.'],
                ],
            ],
        ];
    }
}

if (!function_exists('vp_roadmap_progress')) {
    /** Returns 0..100 percentage of items with status shipped. */
    function vp_roadmap_progress()
    {
        $total = 0; $done = 0;
        foreach (vp_roadmap_data() as $phase) {
            foreach (($phase['items'] ?? []) as $it) {
                $total++;
                if (($it['status'] ?? '') === 'shipped') $done++;
            }
        }
        if ($total === 0) return 0;
        return (int) floor(($done / $total) * 100);
    }
}

if (!function_exists('vp_roadmap_recent')) {
    /**
     * Returns the N most recent "Shipped" items across all phases, sorted by
     * phase + order. Used by the dashboard widget and footer status block.
     */
    function vp_roadmap_recent($limit = 3)
    {
        $items = [];
        foreach (vp_roadmap_data() as $phase) {
            foreach (($phase['items'] ?? []) as $it) {
                if (($it['status'] ?? '') === 'shipped') {
                    $items[] = [
                        'phase' => $phase['name'] ?? '',
                        'title' => $it['title']     ?? '',
                        'detail'=> $it['detail']   ?? '',
                    ];
                }
            }
        }
        // The data struct is already in display order; trim to the limit.
        return array_slice($items, 0, max(1, (int) $limit));
    }
}
